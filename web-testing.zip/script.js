function showMessage() {
  alert("Selamat datang di web profil kelompok T4I! Terima kasih sudah berkunjung.");
}